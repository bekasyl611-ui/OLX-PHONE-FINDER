OLX PHONE FINDER — ANDROID PROJECT 0.1

Это Android Studio-проект, который упаковывает текущую веб-версию в приложение.
В нём есть экран поиска, выбор фото из галереи и переход к результатам OLX.kz.

ВАЖНО:
- Это исходный Android-проект, а не собранный APK.
- Для сборки нужен Android Studio с Android SDK 35 и JDK 17.
- В текущей среде Android SDK и Gradle отсутствуют, поэтому подписанный/установочный APK здесь собрать нельзя.
- Поиск по фото пока показывает выбранную фотографию; ИИ-распознавание ещё не подключено.
- Приложение не сканирует OLX в фоне и не обходит ограничения OLX.

СБОРКА В ANDROID STUDIO:
1. Установи Android Studio на компьютер.
2. Распакуй архив.
3. Открой папку OLX_Phone_Finder_Android через File -> Open.
4. Дождись Gradle Sync и установки Android SDK 35, если Android Studio предложит.
5. Подключи Android-телефон с включённой USB debugging или выбери эмулятор.
6. Нажми Run для установки на устройство.
7. Для APK: Build -> Build Bundle(s) / APK(s) -> Build APK(s).
8. APK будет в app/build/outputs/apk/debug/app-debug.apk.

ТЕХНИЧЕСКИ:
- Package: kz.phonefinder.olx
- Min Android: 6.0 (API 23)
- Target SDK: 35
- Внешние ссылки OLX открываются в браузере.
