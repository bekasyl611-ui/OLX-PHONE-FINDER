plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "kz.phonefinder.olx"
    compileSdk = 35

    defaultConfig {
        applicationId = "kz.phonefinder.olx"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
