const query = document.getElementById('query');
const photo = document.getElementById('photo');
const previewWrap = document.getElementById('preview-wrap');
const preview = document.getElementById('preview');

photo.addEventListener('change', () => {
  const file = photo.files && photo.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')) { alert('Выбери файл изображения.'); return; }
  preview.src = URL.createObjectURL(file);
  previewWrap.hidden = false;
});

document.getElementById('remove-photo').addEventListener('click', () => {
  photo.value = '';
  preview.removeAttribute('src');
  previewWrap.hidden = true;
});

document.querySelectorAll('[data-query]').forEach(button => {
  button.addEventListener('click', () => {
    query.value = button.dataset.query;
    query.focus();
  });
});

function makeOlxUrl(text) {
  const slug = text.trim().toLowerCase()
    .replace(/ё/g, 'е')
    .replace(/[^a-zа-я0-9]+/gi, '-')
    .replace(/^-+|-+$/g, '');
  return `https://www.olx.kz/list/q-${encodeURIComponent(slug)}/`;
}

document.getElementById('search').addEventListener('click', () => {
  const value = query.value.trim();
  if (!value) {
    alert(photo.files.length ? 'Фото добавлено. Для этой версии введи примерное название модели — ИИ-распознавание появится позже.' : 'Введи название телефона или выбери популярный запрос.');
    return;
  }
  localStorage.setItem('olx-phone-finder-last-query', value);
  window.open(makeOlxUrl(value), '_blank', 'noopener');
});

const last = localStorage.getItem('olx-phone-finder-last-query');
if (last) query.value = last;

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
}